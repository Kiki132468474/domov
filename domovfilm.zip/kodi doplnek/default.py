import xbmc
import xbmcgui
import os

# Nastavení cesty k NAS
# Změňte <IP_ADRESA_NAS> na skutečnou IP adresu vašeho NAS
nas_path = "nfs://<10.0.0.15>/video"

# Získání seznamu složek
def get_folders(path):
    try:
        folders = os.listdir(path)
        return folders
    except Exception as e:
        xbmcgui.Dialog().ok("Error", str(e))
        return []

# Zobrazení složek v Kodi
def show_folders(folders):
    if not folders:
        xbmcgui.Dialog().ok("No Folders", "No folders found in the specified directory.")
        return

    for folder in folders:
        xbmcgui.Dialog().ok("Folder", folder)

# Hlavní funkce
if __name__ == "__main__":
    folders = get_folders(nas_path)
    show_folders(folders)